/*
  ==============================================================================

    This file contains the basic framework code for a JUCE plugin editor.

  ==============================================================================
*/

#include "PluginProcessor.h"
#include "PluginEditor.h"

//==============================================================================
PingPongA2AudioProcessorEditor::PingPongA2AudioProcessorEditor (PingPongA2AudioProcessor& p)
    : AudioProcessorEditor (&p), audioProcessor (p)
{
      mGainSlider.setSliderStyle(juce::Slider::LinearVertical);
      mGainSlider.setRange(0.0f,1.0f,0.01f);
      mGainSlider.setValue(0.5f);
      mGainSlider.addListener(this);
      addAndMakeVisible(mGainSlider);
      mGainSlider.setTextBoxStyle(juce::Slider::TextBoxAbove, false, 60, mGainSlider.getTextBoxHeight());
      mGainLabel.setText("Gain", juce::dontSendNotification);
      addAndMakeVisible(mGainLabel);
      mGainLabel.attachToComponent(&mGainSlider, false);
    
    mDelayLengthSlider.setSliderStyle(juce::Slider::LinearVertical);
    mDelayLengthSlider.setRange(400.0f,60000,1.0f);
    mDelayLengthSlider.setValue(1000.0f);
    mDelayLengthSlider.addListener(this);
    addAndMakeVisible(mDelayLengthSlider);
    mDelayLengthSlider.setTextBoxStyle(juce::Slider::TextBoxAbove, false, 60, mGainSlider.getTextBoxHeight());
    mDelayLengthLabel.setText("Delay Length", juce::dontSendNotification);
    addAndMakeVisible(mDelayLengthLabel);
    mDelayLengthLabel.attachToComponent(&mDelayLengthSlider, false);
  
    mFeedbackSlider.setSliderStyle(juce::Slider::LinearVertical);
    mFeedbackSlider.setRange(0.0f,0.99f,0.01f);
    mFeedbackSlider.setValue(0.5f);
    mFeedbackSlider.addListener(this);
    addAndMakeVisible(mFeedbackSlider);
    mFeedbackSlider.setTextBoxStyle(juce::Slider::TextBoxAbove, false, 60, mFeedbackSlider.getTextBoxHeight());
    mFeedbackLabel.setText("Feedback", juce::dontSendNotification);
    addAndMakeVisible(mFeedbackLabel);
    mFeedbackLabel.attachToComponent(&mFeedbackSlider, false);

    mDistDriveSlider.setSliderStyle(juce::Slider::LinearVertical);
    mDistDriveSlider.setRange(0.0f,2.7f,0.01f);
    mDistDriveSlider.setValue(0.5f);
    mDistDriveSlider.addListener(this);
    addAndMakeVisible(mDistDriveSlider);
    mDistDriveSlider.setTextBoxStyle(juce::Slider::TextBoxAbove, false, 60, mDistDriveSlider.getTextBoxHeight());
    mDistDriveLabel.setText("Drive", juce::dontSendNotification);
    addAndMakeVisible(mDistDriveLabel);
    mDistDriveLabel.attachToComponent(&mDistDriveSlider, false);
    
    mDistBlendSlider.setSliderStyle(juce::Slider::LinearVertical);
    mDistBlendSlider.setRange(0.0f,1.0f,0.01f);
    mDistBlendSlider.setValue(0.5f);
    mDistBlendSlider.addListener(this);
    addAndMakeVisible(mDistBlendSlider);
    mDistBlendSlider.setTextBoxStyle(juce::Slider::TextBoxAbove, false, 60, mDistBlendSlider.getTextBoxHeight());
    mDistBlendLabel.setText("Blend", juce::dontSendNotification);
    addAndMakeVisible(mDistBlendLabel);
    mDistBlendLabel.attachToComponent(&mDistBlendSlider, false);
    
    mLPFSlider.setSliderStyle(juce::Slider::LinearVertical);
    mLPFSlider.setRange(0.0f,audioProcessor.mFs/2,1.0f); // Set to nyquest
    mLPFSlider.setValue(15000.0f);
    mLPFSlider.addListener(this);
    addAndMakeVisible(mLPFSlider);
    mLPFSlider.setTextBoxStyle(juce::Slider::TextBoxAbove, false, 60, mLPFSlider.getTextBoxHeight());
    mLPFLAbel.setText("LPF", juce::dontSendNotification);
    addAndMakeVisible(mLPFLAbel);
    mLPFLAbel.attachToComponent(&mLPFSlider, false);
    
    mWetDrySlider.setSliderStyle(juce::Slider::LinearVertical);
    mWetDrySlider.setRange(0.0f,1.0f,0.01f);
    mWetDrySlider.setValue(0.5f);
    mWetDrySlider.addListener(this);
    addAndMakeVisible(mWetDrySlider);
    mWetDrySlider.setTextBoxStyle(juce::Slider::TextBoxAbove, false, 60, mWetDrySlider.getTextBoxHeight());
    mWetDryLabel.setText("Dry/Wet", juce::dontSendNotification);
    addAndMakeVisible(mWetDryLabel);
    mWetDryLabel.attachToComponent(&mWetDrySlider, false);
    
    
    setSize (600, 600);
}

PingPongA2AudioProcessorEditor::~PingPongA2AudioProcessorEditor()
{
}

//==============================================================================
void PingPongA2AudioProcessorEditor::paint (juce::Graphics& g)
{
    // (Our component is opaque, so we must completely fill the background with a solid colour)
    g.fillAll (getLookAndFeel().findColour (juce::ResizableWindow::backgroundColourId));

    g.setColour (juce::Colours::white);
    g.setFont (15.0f);
    g.drawFittedText ("Hello World!", getLocalBounds(), juce::Justification::centred, 1);
}

void PingPongA2AudioProcessorEditor::resized()
{
    mGainSlider.setBounds(40, 50, 60, 200);
    mDelayLengthSlider.setBounds(120, 50, 60, 200);
    mFeedbackSlider.setBounds(200, 50, 60, 200);
    mDistDriveSlider.setBounds(280, 50, 60, 200);
    mDistBlendSlider.setBounds(360, 50, 60, 200);
    mLPFSlider.setBounds(440, 50, 60, 200);
    mWetDrySlider.setBounds(520, 50, 60, 200);
    
}
void PingPongA2AudioProcessorEditor::sliderValueChanged(juce::Slider* slider)
{
    if (slider == &mGainSlider){
        audioProcessor.mLevel = mGainSlider.getValue();
    }

    if (slider == &mDelayLengthSlider){
        audioProcessor.mDL = mDelayLengthSlider.getValue();
    }

    if (slider == &mFeedbackSlider){
        audioProcessor.mFb = mFeedbackSlider.getValue();
    }

    if (slider == &mDistDriveSlider){
        audioProcessor.mDrive = mDistDriveSlider.getValue();
    }

    if (slider == &mDistBlendSlider){
        audioProcessor.mDistBlend = mDistBlendSlider.getValue();
    }
    if (slider == &mLPFSlider){
        audioProcessor.mFc = mLPFSlider.getValue();
    }
//    if (slider == &mWetDrySlider){
//        audioProcessor.mDry = mWetDrySlider.getValue();
//    }

}

